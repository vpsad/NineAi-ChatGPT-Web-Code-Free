import Layout from './index.vue'

export { Layout }

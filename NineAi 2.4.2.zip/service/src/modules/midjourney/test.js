const res = [
  {
      "id": "1130905721475711197",
      "type": 19,
      "content": "**[941d7ab62] a girl --v 5.2 --s 100 --ar 1:1 --c 0 --q .25** - <@1097407545750077461> (turbo)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130905721186291882",
              "filename": "snine_941d7ab62_a_girl_5efd79b5-60a5-40fe-8dc7-909c0d1d83c0.png",
              "size": 6607107,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130905721186291882/snine_941d7ab62_a_girl_5efd79b5-60a5-40fe-8dc7-909c0d1d83c0.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130905721186291882/snine_941d7ab62_a_girl_5efd79b5-60a5-40fe-8dc7-909c0d1d83c0.png",
              "width": 2048,
              "height": 2048,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T16:55:35.212000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::5efd79b5-60a5-40fe-8dc7-909c0d1d83c0",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::5efd79b5-60a5-40fe-8dc7-909c0d1d83c0",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::5efd79b5-60a5-40fe-8dc7-909c0d1d83c0",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::5efd79b5-60a5-40fe-8dc7-909c0d1d83c0",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::5efd79b5-60a5-40fe-8dc7-909c0d1d83c0::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::5efd79b5-60a5-40fe-8dc7-909c0d1d83c0",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::5efd79b5-60a5-40fe-8dc7-909c0d1d83c0",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::5efd79b5-60a5-40fe-8dc7-909c0d1d83c0",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::5efd79b5-60a5-40fe-8dc7-909c0d1d83c0",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130905561161019462",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130905561161019462",
          "type": 0,
          "content": "**[941d7ab62] a girl --v 5.2 --s 100 --ar 1:1 --c 0 --q .25** - <@1097407545750077461> (turbo)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130905560619941948",
                  "filename": "snine_941d7ab62_a_girl_108ce000-624e-4e07-861b-8c7a63b40375.png",
                  "size": 6475329,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130905560619941948/snine_941d7ab62_a_girl_108ce000-624e-4e07-861b-8c7a63b40375.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130905560619941948/snine_941d7ab62_a_girl_108ce000-624e-4e07-861b-8c7a63b40375.png",
                  "width": 2048,
                  "height": 2048,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T16:54:56.990000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::108ce000-624e-4e07-861b-8c7a63b40375",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::108ce000-624e-4e07-861b-8c7a63b40375",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::108ce000-624e-4e07-861b-8c7a63b40375",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::108ce000-624e-4e07-861b-8c7a63b40375",
                          "style": 2,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::108ce000-624e-4e07-861b-8c7a63b40375::SOLO",
                          "style": 1,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::108ce000-624e-4e07-861b-8c7a63b40375",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::108ce000-624e-4e07-861b-8c7a63b40375",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::108ce000-624e-4e07-861b-8c7a63b40375",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::108ce000-624e-4e07-861b-8c7a63b40375",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130905561161019462",
      "type": 0,
      "content": "**[941d7ab62] a girl --v 5.2 --s 100 --ar 1:1 --c 0 --q .25** - <@1097407545750077461> (turbo)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130905560619941948",
              "filename": "snine_941d7ab62_a_girl_108ce000-624e-4e07-861b-8c7a63b40375.png",
              "size": 6475329,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130905560619941948/snine_941d7ab62_a_girl_108ce000-624e-4e07-861b-8c7a63b40375.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130905560619941948/snine_941d7ab62_a_girl_108ce000-624e-4e07-861b-8c7a63b40375.png",
              "width": 2048,
              "height": 2048,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T16:54:56.990000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::108ce000-624e-4e07-861b-8c7a63b40375",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::108ce000-624e-4e07-861b-8c7a63b40375",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::108ce000-624e-4e07-861b-8c7a63b40375",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::108ce000-624e-4e07-861b-8c7a63b40375",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::108ce000-624e-4e07-861b-8c7a63b40375::SOLO",
                      "style": 1,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::108ce000-624e-4e07-861b-8c7a63b40375",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::108ce000-624e-4e07-861b-8c7a63b40375",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::108ce000-624e-4e07-861b-8c7a63b40375",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::108ce000-624e-4e07-861b-8c7a63b40375",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130905536511082546",
      "type": 19,
      "content": "**[09f6dab90] a dog --v 5.2 --s 100 --ar 16:9 --c 0 --q .25** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130905535865167952",
              "filename": "snine_09f6dab90_a_dog_b4f93052-5eaa-4d68-a4cb-0a5925cd1304.png",
              "size": 7215378,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130905535865167952/snine_09f6dab90_a_dog_b4f93052-5eaa-4d68-a4cb-0a5925cd1304.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130905535865167952/snine_09f6dab90_a_dog_b4f93052-5eaa-4d68-a4cb-0a5925cd1304.png",
              "width": 2912,
              "height": 1632,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T16:54:51.113000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::b4f93052-5eaa-4d68-a4cb-0a5925cd1304",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::b4f93052-5eaa-4d68-a4cb-0a5925cd1304",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::b4f93052-5eaa-4d68-a4cb-0a5925cd1304",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::b4f93052-5eaa-4d68-a4cb-0a5925cd1304",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::b4f93052-5eaa-4d68-a4cb-0a5925cd1304::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::b4f93052-5eaa-4d68-a4cb-0a5925cd1304",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::b4f93052-5eaa-4d68-a4cb-0a5925cd1304",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::b4f93052-5eaa-4d68-a4cb-0a5925cd1304",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::b4f93052-5eaa-4d68-a4cb-0a5925cd1304",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130543775178039317",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130543775178039317",
          "type": 0,
          "content": "**[09f6dab90] a dog --v 5.2 --s 100 --ar 16:9 --c 0 --q .25** - <@1097407545750077461> (turbo)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130543774649569351",
                  "filename": "snine_09f6dab90_a_dog_1c463dcf-11f9-4860-9e26-7501cd3befaa.png",
                  "size": 7002725,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130543774649569351/snine_09f6dab90_a_dog_1c463dcf-11f9-4860-9e26-7501cd3befaa.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130543774649569351/snine_09f6dab90_a_dog_1c463dcf-11f9-4860-9e26-7501cd3befaa.png",
                  "width": 2912,
                  "height": 1632,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-17T16:57:20.490000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 1,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 1,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::1c463dcf-11f9-4860-9e26-7501cd3befaa::SOLO",
                          "style": 1,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130904057284939867",
      "type": 19,
      "content": "**[09f6dab90] a dog --v 5.2 --s 100 --ar 16:9 --c 0 --q .25** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130904056760651877",
              "filename": "snine_09f6dab90_a_dog_be98b3cc-3bf4-40be-94ca-516e81c8818e.png",
              "size": 6857991,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130904056760651877/snine_09f6dab90_a_dog_be98b3cc-3bf4-40be-94ca-516e81c8818e.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130904056760651877/snine_09f6dab90_a_dog_be98b3cc-3bf4-40be-94ca-516e81c8818e.png",
              "width": 2912,
              "height": 1632,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T16:48:58.438000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::be98b3cc-3bf4-40be-94ca-516e81c8818e",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::be98b3cc-3bf4-40be-94ca-516e81c8818e",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::be98b3cc-3bf4-40be-94ca-516e81c8818e",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::be98b3cc-3bf4-40be-94ca-516e81c8818e",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::be98b3cc-3bf4-40be-94ca-516e81c8818e::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::be98b3cc-3bf4-40be-94ca-516e81c8818e",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::be98b3cc-3bf4-40be-94ca-516e81c8818e",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::be98b3cc-3bf4-40be-94ca-516e81c8818e",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::be98b3cc-3bf4-40be-94ca-516e81c8818e",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130543775178039317",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130543775178039317",
          "type": 0,
          "content": "**[09f6dab90] a dog --v 5.2 --s 100 --ar 16:9 --c 0 --q .25** - <@1097407545750077461> (turbo)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130543774649569351",
                  "filename": "snine_09f6dab90_a_dog_1c463dcf-11f9-4860-9e26-7501cd3befaa.png",
                  "size": 7002725,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130543774649569351/snine_09f6dab90_a_dog_1c463dcf-11f9-4860-9e26-7501cd3befaa.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130543774649569351/snine_09f6dab90_a_dog_1c463dcf-11f9-4860-9e26-7501cd3befaa.png",
                  "width": 2912,
                  "height": 1632,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-17T16:57:20.490000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 1,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 1,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::1c463dcf-11f9-4860-9e26-7501cd3befaa::SOLO",
                          "style": 1,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130893526079652000",
      "type": 19,
      "content": "**[11757374e] A pig. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130893525299507350",
              "filename": "snine_11757374e_A_pig._83000e74-c9ca-43f1-9988-0d6b736aa299.png",
              "size": 7475081,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130893525299507350/snine_11757374e_A_pig._83000e74-c9ca-43f1-9988-0d6b736aa299.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130893525299507350/snine_11757374e_A_pig._83000e74-c9ca-43f1-9988-0d6b736aa299.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T16:07:07.603000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::83000e74-c9ca-43f1-9988-0d6b736aa299",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::83000e74-c9ca-43f1-9988-0d6b736aa299",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::83000e74-c9ca-43f1-9988-0d6b736aa299",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::83000e74-c9ca-43f1-9988-0d6b736aa299",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::83000e74-c9ca-43f1-9988-0d6b736aa299::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::83000e74-c9ca-43f1-9988-0d6b736aa299",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::83000e74-c9ca-43f1-9988-0d6b736aa299",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::83000e74-c9ca-43f1-9988-0d6b736aa299",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::83000e74-c9ca-43f1-9988-0d6b736aa299",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130892220002742293",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130892220002742293",
          "type": 0,
          "content": "**[11757374e] A pig. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130892219646234704",
                  "filename": "snine_11757374e_A_pig._9b3f878b-3ffc-4bba-ad08-2e11a2e42783.png",
                  "size": 8459107,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130892219646234704/snine_11757374e_A_pig._9b3f878b-3ffc-4bba-ad08-2e11a2e42783.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130892219646234704/snine_11757374e_A_pig._9b3f878b-3ffc-4bba-ad08-2e11a2e42783.png",
                  "width": 1632,
                  "height": 2912,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T16:01:56.210000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 1,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::9b3f878b-3ffc-4bba-ad08-2e11a2e42783::SOLO",
                          "style": 1,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130892429311086784",
      "type": 19,
      "content": "**[11757374e] A pig. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - Image #1 <@1097407545750077461>",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130892429000716358",
              "filename": "snine_11757374e_A_pig._766268ac-52a7-4ee8-979b-819e86e9bb7b.png",
              "size": 1989044,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130892429000716358/snine_11757374e_A_pig._766268ac-52a7-4ee8-979b-819e86e9bb7b.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130892429000716358/snine_11757374e_A_pig._766268ac-52a7-4ee8-979b-819e86e9bb7b.png",
              "width": 816,
              "height": 1456,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T16:02:46.113000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::high_variation::1::766268ac-52a7-4ee8-979b-819e86e9bb7b::SOLO",
                      "style": 2,
                      "label": "Vary (Strong)",
                      "emoji": {
                          "name": "🪄"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::low_variation::1::766268ac-52a7-4ee8-979b-819e86e9bb7b::SOLO",
                      "style": 2,
                      "label": "Vary (Subtle)",
                      "emoji": {
                          "name": "🪄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::50::1::766268ac-52a7-4ee8-979b-819e86e9bb7b::SOLO",
                      "style": 2,
                      "label": "Zoom Out 2x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::75::1::766268ac-52a7-4ee8-979b-819e86e9bb7b::SOLO",
                      "style": 2,
                      "label": "Zoom Out 1.5x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::CustomZoom::766268ac-52a7-4ee8-979b-819e86e9bb7b",
                      "style": 2,
                      "label": "Custom Zoom",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::100::1::766268ac-52a7-4ee8-979b-819e86e9bb7b::SOLO",
                      "style": 2,
                      "label": "Make Square",
                      "emoji": {
                          "name": "↔️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_left::1::766268ac-52a7-4ee8-979b-819e86e9bb7b::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬅️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_right::1::766268ac-52a7-4ee8-979b-819e86e9bb7b::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "➡️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_up::1::766268ac-52a7-4ee8-979b-819e86e9bb7b::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬆️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_down::1::766268ac-52a7-4ee8-979b-819e86e9bb7b::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬇️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::BOOKMARK::766268ac-52a7-4ee8-979b-819e86e9bb7b",
                      "style": 2,
                      "emoji": {
                          "name": "❤️"
                      }
                  },
                  {
                      "type": 2,
                      "style": 5,
                      "label": "Web",
                      "url": "https://www.midjourney.com/app/jobs/766268ac-52a7-4ee8-979b-819e86e9bb7b/"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130892220002742293",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130892220002742293",
          "type": 0,
          "content": "**[11757374e] A pig. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130892219646234704",
                  "filename": "snine_11757374e_A_pig._9b3f878b-3ffc-4bba-ad08-2e11a2e42783.png",
                  "size": 8459107,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130892219646234704/snine_11757374e_A_pig._9b3f878b-3ffc-4bba-ad08-2e11a2e42783.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130892219646234704/snine_11757374e_A_pig._9b3f878b-3ffc-4bba-ad08-2e11a2e42783.png",
                  "width": 1632,
                  "height": 2912,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T16:01:56.210000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 1,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::9b3f878b-3ffc-4bba-ad08-2e11a2e42783::SOLO",
                          "style": 1,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130892220002742293",
      "type": 0,
      "content": "**[11757374e] A pig. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130892219646234704",
              "filename": "snine_11757374e_A_pig._9b3f878b-3ffc-4bba-ad08-2e11a2e42783.png",
              "size": 8459107,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130892219646234704/snine_11757374e_A_pig._9b3f878b-3ffc-4bba-ad08-2e11a2e42783.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130892219646234704/snine_11757374e_A_pig._9b3f878b-3ffc-4bba-ad08-2e11a2e42783.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T16:01:56.210000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                      "style": 1,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::9b3f878b-3ffc-4bba-ad08-2e11a2e42783::SOLO",
                      "style": 1,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::9b3f878b-3ffc-4bba-ad08-2e11a2e42783",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130884065281724627",
      "type": 19,
      "content": "**[09f6dab90] a dog --v 5.2 --s 100 --ar 16:9 --c 0 --q .25** - Image #4 <@1097407545750077461>",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130884064912605325",
              "filename": "snine_09f6dab90_a_dog_788f6fe2-10aa-4fae-b56d-15abb91f38b6.png",
              "size": 1438968,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130884064912605325/snine_09f6dab90_a_dog_788f6fe2-10aa-4fae-b56d-15abb91f38b6.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130884064912605325/snine_09f6dab90_a_dog_788f6fe2-10aa-4fae-b56d-15abb91f38b6.png",
              "width": 1456,
              "height": 816,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T15:29:31.973000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::high_variation::1::788f6fe2-10aa-4fae-b56d-15abb91f38b6::SOLO",
                      "style": 2,
                      "label": "Vary (Strong)",
                      "emoji": {
                          "name": "🪄"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::low_variation::1::788f6fe2-10aa-4fae-b56d-15abb91f38b6::SOLO",
                      "style": 2,
                      "label": "Vary (Subtle)",
                      "emoji": {
                          "name": "🪄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::50::1::788f6fe2-10aa-4fae-b56d-15abb91f38b6::SOLO",
                      "style": 2,
                      "label": "Zoom Out 2x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::75::1::788f6fe2-10aa-4fae-b56d-15abb91f38b6::SOLO",
                      "style": 2,
                      "label": "Zoom Out 1.5x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::CustomZoom::788f6fe2-10aa-4fae-b56d-15abb91f38b6",
                      "style": 2,
                      "label": "Custom Zoom",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::100::1::788f6fe2-10aa-4fae-b56d-15abb91f38b6::SOLO",
                      "style": 2,
                      "label": "Make Square",
                      "emoji": {
                          "name": "↕️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_left::1::788f6fe2-10aa-4fae-b56d-15abb91f38b6::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬅️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_right::1::788f6fe2-10aa-4fae-b56d-15abb91f38b6::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "➡️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_up::1::788f6fe2-10aa-4fae-b56d-15abb91f38b6::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬆️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_down::1::788f6fe2-10aa-4fae-b56d-15abb91f38b6::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬇️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::BOOKMARK::788f6fe2-10aa-4fae-b56d-15abb91f38b6",
                      "style": 2,
                      "emoji": {
                          "name": "❤️"
                      }
                  },
                  {
                      "type": 2,
                      "style": 5,
                      "label": "Web",
                      "url": "https://www.midjourney.com/app/jobs/788f6fe2-10aa-4fae-b56d-15abb91f38b6/"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130543775178039317",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130543775178039317",
          "type": 0,
          "content": "**[09f6dab90] a dog --v 5.2 --s 100 --ar 16:9 --c 0 --q .25** - <@1097407545750077461> (turbo)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130543774649569351",
                  "filename": "snine_09f6dab90_a_dog_1c463dcf-11f9-4860-9e26-7501cd3befaa.png",
                  "size": 7002725,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130543774649569351/snine_09f6dab90_a_dog_1c463dcf-11f9-4860-9e26-7501cd3befaa.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130543774649569351/snine_09f6dab90_a_dog_1c463dcf-11f9-4860-9e26-7501cd3befaa.png",
                  "width": 2912,
                  "height": 1632,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-17T16:57:20.490000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 1,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 1,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::1c463dcf-11f9-4860-9e26-7501cd3befaa::SOLO",
                          "style": 1,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::1c463dcf-11f9-4860-9e26-7501cd3befaa",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130880694290239679",
      "type": 0,
      "content": "**[833318325] <https://s.mj.run/4Ws9Vl6rFic> <https://s.mj.run/4Ws9Vl6rFic> 大熊猫 --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130880693703016449",
              "filename": "snine_833318325_475da673-a8af-42b9-9144-6c2c0c6a5dff.png",
              "size": 5683143,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130880693703016449/snine_833318325_475da673-a8af-42b9-9144-6c2c0c6a5dff.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130880693703016449/snine_833318325_475da673-a8af-42b9-9144-6c2c0c6a5dff.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T15:16:08.266000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::475da673-a8af-42b9-9144-6c2c0c6a5dff",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::475da673-a8af-42b9-9144-6c2c0c6a5dff",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::475da673-a8af-42b9-9144-6c2c0c6a5dff",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::475da673-a8af-42b9-9144-6c2c0c6a5dff",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::475da673-a8af-42b9-9144-6c2c0c6a5dff::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::475da673-a8af-42b9-9144-6c2c0c6a5dff",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::475da673-a8af-42b9-9144-6c2c0c6a5dff",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::475da673-a8af-42b9-9144-6c2c0c6a5dff",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::475da673-a8af-42b9-9144-6c2c0c6a5dff",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130879370035200092",
      "type": 0,
      "content": "**[d0b2d6d09] young girl，Highly detailed，Vivid Colors，Makoto Shinkai，full body shot，looking at viewer，blush，sailor dress，shinto shrine --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130879369355735121",
              "filename": "snine_d0b2d6d09_young_girlHighly_detailedVivid_ColorsMakoto_Sh_794bc65b-e817-414d-a03b-2f9e20b6c856.png",
              "size": 7754691,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130879369355735121/snine_d0b2d6d09_young_girlHighly_detailedVivid_ColorsMakoto_Sh_794bc65b-e817-414d-a03b-2f9e20b6c856.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130879369355735121/snine_d0b2d6d09_young_girlHighly_detailedVivid_ColorsMakoto_Sh_794bc65b-e817-414d-a03b-2f9e20b6c856.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T15:10:52.539000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::794bc65b-e817-414d-a03b-2f9e20b6c856",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::794bc65b-e817-414d-a03b-2f9e20b6c856",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::794bc65b-e817-414d-a03b-2f9e20b6c856",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::794bc65b-e817-414d-a03b-2f9e20b6c856",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::794bc65b-e817-414d-a03b-2f9e20b6c856::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::794bc65b-e817-414d-a03b-2f9e20b6c856",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::794bc65b-e817-414d-a03b-2f9e20b6c856",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::794bc65b-e817-414d-a03b-2f9e20b6c856",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::794bc65b-e817-414d-a03b-2f9e20b6c856",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130875557211537430",
      "type": 19,
      "content": "**[e9a3f7b40] <https://s.mj.run/cNUqBpy9GZg> <https://s.mj.run/cNUqBpy9GZg> Anime style --niji 5 --ar 9:16 --c 0 --q 1** - Variations (Strong) by <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130875556834058311",
              "filename": "snine_e9a3f7b40_93b9abee-f002-44df-91bd-d3d76c0e3fd7.png",
              "size": 6129190,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130875556834058311/snine_e9a3f7b40_93b9abee-f002-44df-91bd-d3d76c0e3fd7.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130875556834058311/snine_e9a3f7b40_93b9abee-f002-44df-91bd-d3d76c0e3fd7.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T14:55:43.491000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::93b9abee-f002-44df-91bd-d3d76c0e3fd7",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::93b9abee-f002-44df-91bd-d3d76c0e3fd7",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::93b9abee-f002-44df-91bd-d3d76c0e3fd7",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::93b9abee-f002-44df-91bd-d3d76c0e3fd7",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::93b9abee-f002-44df-91bd-d3d76c0e3fd7::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::93b9abee-f002-44df-91bd-d3d76c0e3fd7",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::93b9abee-f002-44df-91bd-d3d76c0e3fd7",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::93b9abee-f002-44df-91bd-d3d76c0e3fd7",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::93b9abee-f002-44df-91bd-d3d76c0e3fd7",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130793924370374676",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130793924370374676",
          "type": 19,
          "content": "**[e9a3f7b40] <https://s.mj.run/cNUqBpy9GZg> <https://s.mj.run/cNUqBpy9GZg> Anime style --niji 5 --ar 9:16 --c 0 --q 1** - Image #4 <@1097407545750077461>",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130793924043214938",
                  "filename": "snine_e9a3f7b40_08415b0f-a989-4b75-99a4-5c62dafce805.png",
                  "size": 1433118,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130793924043214938/snine_e9a3f7b40_08415b0f-a989-4b75-99a4-5c62dafce805.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130793924043214938/snine_e9a3f7b40_08415b0f-a989-4b75-99a4-5c62dafce805.png",
                  "width": 816,
                  "height": 1456,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T09:31:20.705000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::high_variation::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                          "style": 1,
                          "label": "Vary (Strong)",
                          "emoji": {
                              "name": "🪄"
                          }
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::low_variation::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                          "style": 2,
                          "label": "Vary (Subtle)",
                          "emoji": {
                              "name": "🪄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::Outpaint::50::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                          "style": 2,
                          "label": "Zoom Out 2x",
                          "emoji": {
                              "name": "🔍"
                          }
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::Outpaint::75::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                          "style": 2,
                          "label": "Zoom Out 1.5x",
                          "emoji": {
                              "name": "🔍"
                          }
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::CustomZoom::08415b0f-a989-4b75-99a4-5c62dafce805",
                          "style": 2,
                          "label": "Custom Zoom",
                          "emoji": {
                              "name": "🔍"
                          }
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::Outpaint::100::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                          "style": 2,
                          "label": "Make Square",
                          "emoji": {
                              "name": "↔️"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::pan_left::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "⬅️"
                          }
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::pan_right::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "➡️"
                          }
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::pan_up::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "⬆️"
                          }
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::pan_down::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "⬇️"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::BOOKMARK::08415b0f-a989-4b75-99a4-5c62dafce805",
                          "style": 2,
                          "emoji": {
                              "name": "❤️"
                          }
                      },
                      {
                          "type": 2,
                          "style": 5,
                          "label": "Web",
                          "url": "https://www.midjourney.com/app/jobs/08415b0f-a989-4b75-99a4-5c62dafce805/"
                      }
                  ]
              }
          ],
          "message_reference": {
              "channel_id": "1109782665743306813",
              "message_id": "1130793386983567390",
              "guild_id": "1097409128491651132"
          }
      }
  },
  {
      "id": "1130856590870839367",
      "type": 0,
      "content": "**[3a8012699] <https://s.mj.run/5VdCwQC8VU4> <https://s.mj.run/5VdCwQC8VU4> The KFC logo is a classic red and white image that is instantly recognizable. The camera type capturing this image would be a close-up shot, focusing on the details of the logo. The camera lens type would be a macro lens to capture the intricate lines and shapes of the logo. The time of day for this photograph would be during daylight hours to showcase the vibrant colors of the logo. In terms of style, the photograph would have a clean and modern aesthetic, with a focus on sharp lines and contrast. The red and white colors would pop against a clean background, creating a visually striking image. As for the type of film used, it would be a digital format to ensure the highest level of detail and clarity in capturing the logo. This would allow for precise rendering of the red and white colors, showcasing the brand's iconic image in all its glory. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130856590178799799",
              "filename": "snine_3a8012699_062c72c0-d748-49c4-ad24-e58c26567036.png",
              "size": 4601119,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130856590178799799/snine_3a8012699_062c72c0-d748-49c4-ad24-e58c26567036.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130856590178799799/snine_3a8012699_062c72c0-d748-49c4-ad24-e58c26567036.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T13:40:21.563000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::062c72c0-d748-49c4-ad24-e58c26567036",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::062c72c0-d748-49c4-ad24-e58c26567036",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::062c72c0-d748-49c4-ad24-e58c26567036",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::062c72c0-d748-49c4-ad24-e58c26567036",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::062c72c0-d748-49c4-ad24-e58c26567036::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::062c72c0-d748-49c4-ad24-e58c26567036",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::062c72c0-d748-49c4-ad24-e58c26567036",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::062c72c0-d748-49c4-ad24-e58c26567036",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::062c72c0-d748-49c4-ad24-e58c26567036",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130793924370374676",
      "type": 19,
      "content": "**[e9a3f7b40] <https://s.mj.run/cNUqBpy9GZg> <https://s.mj.run/cNUqBpy9GZg> Anime style --niji 5 --ar 9:16 --c 0 --q 1** - Image #4 <@1097407545750077461>",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130793924043214938",
              "filename": "snine_e9a3f7b40_08415b0f-a989-4b75-99a4-5c62dafce805.png",
              "size": 1433118,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130793924043214938/snine_e9a3f7b40_08415b0f-a989-4b75-99a4-5c62dafce805.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130793924043214938/snine_e9a3f7b40_08415b0f-a989-4b75-99a4-5c62dafce805.png",
              "width": 816,
              "height": 1456,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T09:31:20.705000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::high_variation::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                      "style": 1,
                      "label": "Vary (Strong)",
                      "emoji": {
                          "name": "🪄"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::low_variation::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                      "style": 2,
                      "label": "Vary (Subtle)",
                      "emoji": {
                          "name": "🪄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::50::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                      "style": 2,
                      "label": "Zoom Out 2x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::75::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                      "style": 2,
                      "label": "Zoom Out 1.5x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::CustomZoom::08415b0f-a989-4b75-99a4-5c62dafce805",
                      "style": 2,
                      "label": "Custom Zoom",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::100::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                      "style": 2,
                      "label": "Make Square",
                      "emoji": {
                          "name": "↔️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_left::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬅️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_right::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "➡️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_up::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬆️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_down::1::08415b0f-a989-4b75-99a4-5c62dafce805::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬇️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::BOOKMARK::08415b0f-a989-4b75-99a4-5c62dafce805",
                      "style": 2,
                      "emoji": {
                          "name": "❤️"
                      }
                  },
                  {
                      "type": 2,
                      "style": 5,
                      "label": "Web",
                      "url": "https://www.midjourney.com/app/jobs/08415b0f-a989-4b75-99a4-5c62dafce805/"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130793386983567390",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130793386983567390",
          "type": 0,
          "content": "**[e9a3f7b40] <https://s.mj.run/cNUqBpy9GZg> <https://s.mj.run/cNUqBpy9GZg> Anime style --niji 5 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130793386253766716",
                  "filename": "snine_e9a3f7b40_585b26a2-5d39-4c80-a1e1-c8617764227d.png",
                  "size": 5982014,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130793386253766716/snine_e9a3f7b40_585b26a2-5d39-4c80-a1e1-c8617764227d.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130793386253766716/snine_e9a3f7b40_585b26a2-5d39-4c80-a1e1-c8617764227d.png",
                  "width": 1632,
                  "height": 2912,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T09:29:12.582000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::585b26a2-5d39-4c80-a1e1-c8617764227d",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::585b26a2-5d39-4c80-a1e1-c8617764227d",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::585b26a2-5d39-4c80-a1e1-c8617764227d",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::585b26a2-5d39-4c80-a1e1-c8617764227d",
                          "style": 1,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::585b26a2-5d39-4c80-a1e1-c8617764227d::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::585b26a2-5d39-4c80-a1e1-c8617764227d",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::585b26a2-5d39-4c80-a1e1-c8617764227d",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::585b26a2-5d39-4c80-a1e1-c8617764227d",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::585b26a2-5d39-4c80-a1e1-c8617764227d",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130793386983567390",
      "type": 0,
      "content": "**[e9a3f7b40] <https://s.mj.run/cNUqBpy9GZg> <https://s.mj.run/cNUqBpy9GZg> Anime style --niji 5 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130793386253766716",
              "filename": "snine_e9a3f7b40_585b26a2-5d39-4c80-a1e1-c8617764227d.png",
              "size": 5982014,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130793386253766716/snine_e9a3f7b40_585b26a2-5d39-4c80-a1e1-c8617764227d.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130793386253766716/snine_e9a3f7b40_585b26a2-5d39-4c80-a1e1-c8617764227d.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T09:29:12.582000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::585b26a2-5d39-4c80-a1e1-c8617764227d",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::585b26a2-5d39-4c80-a1e1-c8617764227d",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::585b26a2-5d39-4c80-a1e1-c8617764227d",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::585b26a2-5d39-4c80-a1e1-c8617764227d",
                      "style": 1,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::585b26a2-5d39-4c80-a1e1-c8617764227d::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::585b26a2-5d39-4c80-a1e1-c8617764227d",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::585b26a2-5d39-4c80-a1e1-c8617764227d",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::585b26a2-5d39-4c80-a1e1-c8617764227d",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::585b26a2-5d39-4c80-a1e1-c8617764227d",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130792626791125083",
      "type": 0,
      "content": "**[1064c6356] <https://s.mj.run/9N7RYOFIpH8> <https://s.mj.run/9N7RYOFIpH8> Cute style --niji 5 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130792626082291823",
              "filename": "snine_1064c6356_6c66398d-b948-4b61-9481-6d863dbf6f5e.png",
              "size": 4874724,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130792626082291823/snine_1064c6356_6c66398d-b948-4b61-9481-6d863dbf6f5e.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130792626082291823/snine_1064c6356_6c66398d-b948-4b61-9481-6d863dbf6f5e.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T09:26:11.338000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::6c66398d-b948-4b61-9481-6d863dbf6f5e",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::6c66398d-b948-4b61-9481-6d863dbf6f5e",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::6c66398d-b948-4b61-9481-6d863dbf6f5e",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::6c66398d-b948-4b61-9481-6d863dbf6f5e",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::6c66398d-b948-4b61-9481-6d863dbf6f5e::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::6c66398d-b948-4b61-9481-6d863dbf6f5e",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::6c66398d-b948-4b61-9481-6d863dbf6f5e",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::6c66398d-b948-4b61-9481-6d863dbf6f5e",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::6c66398d-b948-4b61-9481-6d863dbf6f5e",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130791877789110292",
      "type": 0,
      "content": "**[38649f8e3] <https://s.mj.run/rnfD2OC9-Y8> <https://s.mj.run/rnfD2OC9-Y8> A cute cat --niji 5 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130791877260619826",
              "filename": "snine_38649f8e3_6d40d3f2-1a24-4f7e-af00-8b5c07e04dac.png",
              "size": 5136729,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130791877260619826/snine_38649f8e3_6d40d3f2-1a24-4f7e-af00-8b5c07e04dac.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130791877260619826/snine_38649f8e3_6d40d3f2-1a24-4f7e-af00-8b5c07e04dac.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T09:23:12.762000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::6d40d3f2-1a24-4f7e-af00-8b5c07e04dac",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::6d40d3f2-1a24-4f7e-af00-8b5c07e04dac",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::6d40d3f2-1a24-4f7e-af00-8b5c07e04dac",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::6d40d3f2-1a24-4f7e-af00-8b5c07e04dac",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::6d40d3f2-1a24-4f7e-af00-8b5c07e04dac::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::6d40d3f2-1a24-4f7e-af00-8b5c07e04dac",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::6d40d3f2-1a24-4f7e-af00-8b5c07e04dac",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::6d40d3f2-1a24-4f7e-af00-8b5c07e04dac",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::6d40d3f2-1a24-4f7e-af00-8b5c07e04dac",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130788581942767648",
      "type": 19,
      "content": "**[6afbd35a2] <https://s.mj.run/UXREhTsSEFk> <https://s.mj.run/UXREhTsSEFk> the person in the picture is coding with silly face change the picture to cartoon style --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - Image #4 <@1097407545750077461>",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130788581636579408",
              "filename": "snine_6afbd35a2_5eec18a3-acef-4e11-a3d4-166b33bb2d00.png",
              "size": 1418113,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130788581636579408/snine_6afbd35a2_5eec18a3-acef-4e11-a3d4-166b33bb2d00.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130788581636579408/snine_6afbd35a2_5eec18a3-acef-4e11-a3d4-166b33bb2d00.png",
              "width": 1024,
              "height": 1024,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T09:10:06.971000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::high_variation::1::5eec18a3-acef-4e11-a3d4-166b33bb2d00::SOLO",
                      "style": 2,
                      "label": "Vary (Strong)",
                      "emoji": {
                          "name": "🪄"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::low_variation::1::5eec18a3-acef-4e11-a3d4-166b33bb2d00::SOLO",
                      "style": 2,
                      "label": "Vary (Subtle)",
                      "emoji": {
                          "name": "🪄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::50::1::5eec18a3-acef-4e11-a3d4-166b33bb2d00::SOLO",
                      "style": 2,
                      "label": "Zoom Out 2x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::75::1::5eec18a3-acef-4e11-a3d4-166b33bb2d00::SOLO",
                      "style": 2,
                      "label": "Zoom Out 1.5x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::CustomZoom::5eec18a3-acef-4e11-a3d4-166b33bb2d00",
                      "style": 2,
                      "label": "Custom Zoom",
                      "emoji": {
                          "name": "🔍"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_left::1::5eec18a3-acef-4e11-a3d4-166b33bb2d00::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬅️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_right::1::5eec18a3-acef-4e11-a3d4-166b33bb2d00::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "➡️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_up::1::5eec18a3-acef-4e11-a3d4-166b33bb2d00::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬆️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_down::1::5eec18a3-acef-4e11-a3d4-166b33bb2d00::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬇️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::BOOKMARK::5eec18a3-acef-4e11-a3d4-166b33bb2d00",
                      "style": 2,
                      "emoji": {
                          "name": "❤️"
                      }
                  },
                  {
                      "type": 2,
                      "style": 5,
                      "label": "Web",
                      "url": "https://www.midjourney.com/app/jobs/5eec18a3-acef-4e11-a3d4-166b33bb2d00/"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130788208309973105",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130788208309973105",
          "type": 0,
          "content": "**[6afbd35a2] <https://s.mj.run/UXREhTsSEFk> <https://s.mj.run/UXREhTsSEFk> the person in the picture is coding with silly face change the picture to cartoon style --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130788206904885248",
                  "filename": "snine_6afbd35a2_5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3.png",
                  "size": 5650217,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130788206904885248/snine_6afbd35a2_5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130788206904885248/snine_6afbd35a2_5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3.png",
                  "width": 2048,
                  "height": 2048,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T09:08:37.890000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                          "style": 1,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130788208309973105",
      "type": 0,
      "content": "**[6afbd35a2] <https://s.mj.run/UXREhTsSEFk> <https://s.mj.run/UXREhTsSEFk> the person in the picture is coding with silly face change the picture to cartoon style --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130788206904885248",
              "filename": "snine_6afbd35a2_5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3.png",
              "size": 5650217,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130788206904885248/snine_6afbd35a2_5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130788206904885248/snine_6afbd35a2_5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3.png",
              "width": 2048,
              "height": 2048,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T09:08:37.890000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                      "style": 1,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::5bc35bd1-e8fd-40df-b1ec-42be4b2b96d3",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130787925001523271",
      "type": 0,
      "content": "**[cc95b0b82] <https://s.mj.run/qDvu6buqErc> <https://s.mj.run/qDvu6buqErc> Sure, I can help you with that. Here's the translation: \"I would like you to generate a scene and clothing for me.\" --niji 5 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130787924523356281",
              "filename": "snine_cc95b0b82_98b74dc7-e102-4dab-a85c-3d2fcfac199f.png",
              "size": 6227668,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130787924523356281/snine_cc95b0b82_98b74dc7-e102-4dab-a85c-3d2fcfac199f.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130787924523356281/snine_cc95b0b82_98b74dc7-e102-4dab-a85c-3d2fcfac199f.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T09:07:30.344000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::98b74dc7-e102-4dab-a85c-3d2fcfac199f",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::98b74dc7-e102-4dab-a85c-3d2fcfac199f",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::98b74dc7-e102-4dab-a85c-3d2fcfac199f",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::98b74dc7-e102-4dab-a85c-3d2fcfac199f",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::98b74dc7-e102-4dab-a85c-3d2fcfac199f::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::98b74dc7-e102-4dab-a85c-3d2fcfac199f",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::98b74dc7-e102-4dab-a85c-3d2fcfac199f",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::98b74dc7-e102-4dab-a85c-3d2fcfac199f",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::98b74dc7-e102-4dab-a85c-3d2fcfac199f",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130787398654099528",
      "type": 0,
      "content": "**[673fcb323] <https://s.mj.run/aSVwnVHEthA> <https://s.mj.run/aSVwnVHEthA> This person is wearing a white t-shirt and coding. The person's face looks silly. --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130787398020771850",
              "filename": "snine_673fcb323_6fc521c0-6740-4a86-8c15-b53e52f2f558.png",
              "size": 5716054,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130787398020771850/snine_673fcb323_6fc521c0-6740-4a86-8c15-b53e52f2f558.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130787398020771850/snine_673fcb323_6fc521c0-6740-4a86-8c15-b53e52f2f558.png",
              "width": 2048,
              "height": 2048,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T09:05:24.853000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::6fc521c0-6740-4a86-8c15-b53e52f2f558",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::6fc521c0-6740-4a86-8c15-b53e52f2f558",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::6fc521c0-6740-4a86-8c15-b53e52f2f558",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::6fc521c0-6740-4a86-8c15-b53e52f2f558",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::6fc521c0-6740-4a86-8c15-b53e52f2f558::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::6fc521c0-6740-4a86-8c15-b53e52f2f558",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::6fc521c0-6740-4a86-8c15-b53e52f2f558",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::6fc521c0-6740-4a86-8c15-b53e52f2f558",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::6fc521c0-6740-4a86-8c15-b53e52f2f558",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130786260282261564",
      "type": 0,
      "content": "**[1c4640417] <https://s.mj.run/SWrB7ure2zc> <https://s.mj.run/SWrB7ure2zc> A beautiful girl --niji 5 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130786259481133096",
              "filename": "snine_1c4640417_d9db8405-d343-4050-9cf7-2b0f769d0523.png",
              "size": 7086746,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130786259481133096/snine_1c4640417_d9db8405-d343-4050-9cf7-2b0f769d0523.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130786259481133096/snine_1c4640417_d9db8405-d343-4050-9cf7-2b0f769d0523.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T09:00:53.444000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::d9db8405-d343-4050-9cf7-2b0f769d0523",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::d9db8405-d343-4050-9cf7-2b0f769d0523",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::d9db8405-d343-4050-9cf7-2b0f769d0523",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::d9db8405-d343-4050-9cf7-2b0f769d0523",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::d9db8405-d343-4050-9cf7-2b0f769d0523::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::d9db8405-d343-4050-9cf7-2b0f769d0523",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::d9db8405-d343-4050-9cf7-2b0f769d0523",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::d9db8405-d343-4050-9cf7-2b0f769d0523",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::d9db8405-d343-4050-9cf7-2b0f769d0523",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130785208577302560",
      "type": 0,
      "content": "**[a54277844] <https://s.mj.run/YVKc99P4usU> <https://s.mj.run/YVKc99P4usU> A beautiful girl --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130785208367583332",
              "filename": "snine_a54277844_2d233264-3fe4-4c62-8dae-4f26a875f6ef.png",
              "size": 6719667,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130785208367583332/snine_a54277844_2d233264-3fe4-4c62-8dae-4f26a875f6ef.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130785208367583332/snine_a54277844_2d233264-3fe4-4c62-8dae-4f26a875f6ef.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:56:42.698000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::2d233264-3fe4-4c62-8dae-4f26a875f6ef",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::2d233264-3fe4-4c62-8dae-4f26a875f6ef",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::2d233264-3fe4-4c62-8dae-4f26a875f6ef",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::2d233264-3fe4-4c62-8dae-4f26a875f6ef",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::2d233264-3fe4-4c62-8dae-4f26a875f6ef::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::2d233264-3fe4-4c62-8dae-4f26a875f6ef",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::2d233264-3fe4-4c62-8dae-4f26a875f6ef",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::2d233264-3fe4-4c62-8dae-4f26a875f6ef",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::2d233264-3fe4-4c62-8dae-4f26a875f6ef",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130785020303380592",
      "type": 19,
      "content": "**[5ec691cb1] indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - Image #3 <@1097407545750077461>",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130785019930103839",
              "filename": "snine_5ec691cb1_indoorbedside_tablesoft_lightingfeaturesreal_64dd2d1a-93ff-495e-b4ae-4023820bfeff.png",
              "size": 1427943,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130785019930103839/snine_5ec691cb1_indoorbedside_tablesoft_lightingfeaturesreal_64dd2d1a-93ff-495e-b4ae-4023820bfeff.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130785019930103839/snine_5ec691cb1_indoorbedside_tablesoft_lightingfeaturesreal_64dd2d1a-93ff-495e-b4ae-4023820bfeff.png",
              "width": 816,
              "height": 1456,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:55:57.810000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::high_variation::1::64dd2d1a-93ff-495e-b4ae-4023820bfeff::SOLO",
                      "style": 2,
                      "label": "Vary (Strong)",
                      "emoji": {
                          "name": "🪄"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::low_variation::1::64dd2d1a-93ff-495e-b4ae-4023820bfeff::SOLO",
                      "style": 2,
                      "label": "Vary (Subtle)",
                      "emoji": {
                          "name": "🪄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::50::1::64dd2d1a-93ff-495e-b4ae-4023820bfeff::SOLO",
                      "style": 2,
                      "label": "Zoom Out 2x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::75::1::64dd2d1a-93ff-495e-b4ae-4023820bfeff::SOLO",
                      "style": 2,
                      "label": "Zoom Out 1.5x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::CustomZoom::64dd2d1a-93ff-495e-b4ae-4023820bfeff",
                      "style": 2,
                      "label": "Custom Zoom",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::100::1::64dd2d1a-93ff-495e-b4ae-4023820bfeff::SOLO",
                      "style": 2,
                      "label": "Make Square",
                      "emoji": {
                          "name": "↔️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_left::1::64dd2d1a-93ff-495e-b4ae-4023820bfeff::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬅️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_right::1::64dd2d1a-93ff-495e-b4ae-4023820bfeff::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "➡️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_up::1::64dd2d1a-93ff-495e-b4ae-4023820bfeff::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬆️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_down::1::64dd2d1a-93ff-495e-b4ae-4023820bfeff::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬇️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::BOOKMARK::64dd2d1a-93ff-495e-b4ae-4023820bfeff",
                      "style": 2,
                      "emoji": {
                          "name": "❤️"
                      }
                  },
                  {
                      "type": 2,
                      "style": 5,
                      "label": "Web",
                      "url": "https://www.midjourney.com/app/jobs/64dd2d1a-93ff-495e-b4ae-4023820bfeff/"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130777015482601512",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130777015482601512",
          "type": 0,
          "content": "**[5ec691cb1] indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130777014870220881",
                  "filename": "snine_5ec691cb1_indoorbedside_tablesoft_lightingfeaturesreal_d44e6121-c702-424c-86f9-04b75d9559c7.png",
                  "size": 6264746,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130777014870220881/snine_5ec691cb1_indoorbedside_tablesoft_lightingfeaturesreal_d44e6121-c702-424c-86f9-04b75d9559c7.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130777014870220881/snine_5ec691cb1_indoorbedside_tablesoft_lightingfeaturesreal_d44e6121-c702-424c-86f9-04b75d9559c7.png",
                  "width": 1632,
                  "height": 2912,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T08:24:09.312000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::d44e6121-c702-424c-86f9-04b75d9559c7",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::d44e6121-c702-424c-86f9-04b75d9559c7",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::d44e6121-c702-424c-86f9-04b75d9559c7",
                          "style": 1,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::d44e6121-c702-424c-86f9-04b75d9559c7",
                          "style": 2,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::d44e6121-c702-424c-86f9-04b75d9559c7::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::d44e6121-c702-424c-86f9-04b75d9559c7",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::d44e6121-c702-424c-86f9-04b75d9559c7",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::d44e6121-c702-424c-86f9-04b75d9559c7",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::d44e6121-c702-424c-86f9-04b75d9559c7",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130784886001770558",
      "type": 19,
      "content": "**[628fc2b5a] <https://s.mj.run/F8EPwOiVDww> <https://s.mj.run/F8EPwOiVDww> Sure, I will provide you with English translations in an AI style that closely resembles your own language. --v 5.1 --s 100 --ar 9:16 --c 0 --q 2** - Variations by <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130784885406175282",
              "filename": "snine_628fc2b5a_4142cba0-3fc7-4523-a8ae-780c73738ade.png",
              "size": 7204596,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130784885406175282/snine_628fc2b5a_4142cba0-3fc7-4523-a8ae-780c73738ade.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130784885406175282/snine_628fc2b5a_4142cba0-3fc7-4523-a8ae-780c73738ade.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:55:25.790000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::4142cba0-3fc7-4523-a8ae-780c73738ade",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::4142cba0-3fc7-4523-a8ae-780c73738ade",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::4142cba0-3fc7-4523-a8ae-780c73738ade",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::4142cba0-3fc7-4523-a8ae-780c73738ade",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::4142cba0-3fc7-4523-a8ae-780c73738ade::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::4142cba0-3fc7-4523-a8ae-780c73738ade",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::4142cba0-3fc7-4523-a8ae-780c73738ade",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::4142cba0-3fc7-4523-a8ae-780c73738ade",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::4142cba0-3fc7-4523-a8ae-780c73738ade",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130781256389492787",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130781256389492787",
          "type": 0,
          "content": "**[628fc2b5a] <https://s.mj.run/F8EPwOiVDww> <https://s.mj.run/F8EPwOiVDww> Sure, I will provide you with English translations in an AI style that closely resembles your own language. --v 5.1 --s 100 --ar 9:16 --c 0 --q 2** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130781255647109200",
                  "filename": "snine_628fc2b5a_4b562ae4-50dc-4109-8e4f-ecdbc902efbd.png",
                  "size": 7595981,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130781255647109200/snine_628fc2b5a_4b562ae4-50dc-4109-8e4f-ecdbc902efbd.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130781255647109200/snine_628fc2b5a_4b562ae4-50dc-4109-8e4f-ecdbc902efbd.png",
                  "width": 1632,
                  "height": 2912,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T08:41:00.423000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::4b562ae4-50dc-4109-8e4f-ecdbc902efbd::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 1,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130784725754183730",
      "type": 0,
      "content": "**[8fa70a85e] <https://s.mj.run/BGoPuAW6Bs0> <https://s.mj.run/BGoPuAW6Bs0> Please modify the image into a cartoon style. --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130784725095694466",
              "filename": "snine_8fa70a85e_421b33a4-5db5-4a1a-8791-3db87bb4fe7d.png",
              "size": 6486307,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130784725095694466/snine_8fa70a85e_421b33a4-5db5-4a1a-8791-3db87bb4fe7d.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130784725095694466/snine_8fa70a85e_421b33a4-5db5-4a1a-8791-3db87bb4fe7d.png",
              "width": 2048,
              "height": 2048,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:54:47.584000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::421b33a4-5db5-4a1a-8791-3db87bb4fe7d",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::421b33a4-5db5-4a1a-8791-3db87bb4fe7d",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::421b33a4-5db5-4a1a-8791-3db87bb4fe7d",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::421b33a4-5db5-4a1a-8791-3db87bb4fe7d",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::421b33a4-5db5-4a1a-8791-3db87bb4fe7d::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::421b33a4-5db5-4a1a-8791-3db87bb4fe7d",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::421b33a4-5db5-4a1a-8791-3db87bb4fe7d",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::421b33a4-5db5-4a1a-8791-3db87bb4fe7d",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::421b33a4-5db5-4a1a-8791-3db87bb4fe7d",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130784701351739553",
      "type": 19,
      "content": "**[944e9309c] <https://s.mj.run/lQ5vzlVA3EY> <https://s.mj.run/lQ5vzlVA3EY> indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - Image #4 <@1097407545750077461>",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130784701167194142",
              "filename": "snine_944e9309c_9b592503-40d9-4b2d-8069-9c43f9b0cb99.png",
              "size": 1357855,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130784701167194142/snine_944e9309c_9b592503-40d9-4b2d-8069-9c43f9b0cb99.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130784701167194142/snine_944e9309c_9b592503-40d9-4b2d-8069-9c43f9b0cb99.png",
              "width": 1024,
              "height": 1024,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:54:41.766000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::high_variation::1::9b592503-40d9-4b2d-8069-9c43f9b0cb99::SOLO",
                      "style": 2,
                      "label": "Vary (Strong)",
                      "emoji": {
                          "name": "🪄"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::low_variation::1::9b592503-40d9-4b2d-8069-9c43f9b0cb99::SOLO",
                      "style": 2,
                      "label": "Vary (Subtle)",
                      "emoji": {
                          "name": "🪄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::50::1::9b592503-40d9-4b2d-8069-9c43f9b0cb99::SOLO",
                      "style": 2,
                      "label": "Zoom Out 2x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::75::1::9b592503-40d9-4b2d-8069-9c43f9b0cb99::SOLO",
                      "style": 2,
                      "label": "Zoom Out 1.5x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::CustomZoom::9b592503-40d9-4b2d-8069-9c43f9b0cb99",
                      "style": 2,
                      "label": "Custom Zoom",
                      "emoji": {
                          "name": "🔍"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_left::1::9b592503-40d9-4b2d-8069-9c43f9b0cb99::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬅️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_right::1::9b592503-40d9-4b2d-8069-9c43f9b0cb99::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "➡️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_up::1::9b592503-40d9-4b2d-8069-9c43f9b0cb99::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬆️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_down::1::9b592503-40d9-4b2d-8069-9c43f9b0cb99::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬇️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::BOOKMARK::9b592503-40d9-4b2d-8069-9c43f9b0cb99",
                      "style": 2,
                      "emoji": {
                          "name": "❤️"
                      }
                  },
                  {
                      "type": 2,
                      "style": 5,
                      "label": "Web",
                      "url": "https://www.midjourney.com/app/jobs/9b592503-40d9-4b2d-8069-9c43f9b0cb99/"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130781230015721543",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130781230015721543",
          "type": 0,
          "content": "**[944e9309c] <https://s.mj.run/lQ5vzlVA3EY> <https://s.mj.run/lQ5vzlVA3EY> indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130781229407535194",
                  "filename": "snine_944e9309c_efb876c3-0024-49d2-a41f-cc6cf6ce5d3f.png",
                  "size": 5496105,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130781229407535194/snine_944e9309c_efb876c3-0024-49d2-a41f-cc6cf6ce5d3f.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130781229407535194/snine_944e9309c_efb876c3-0024-49d2-a41f-cc6cf6ce5d3f.png",
                  "width": 2048,
                  "height": 2048,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T08:40:54.135000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 1,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 1,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130784669965758566",
      "type": 19,
      "content": "**[628fc2b5a] <https://s.mj.run/F8EPwOiVDww> <https://s.mj.run/F8EPwOiVDww> Sure, I will provide you with English translations in an AI style that closely resembles your own language. --v 5.1 --s 100 --ar 9:16 --c 0 --q 2** - Variations by <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130784669378547755",
              "filename": "snine_628fc2b5a_0e9faeb3-27e8-49b7-9021-419aa36e919d.png",
              "size": 7385815,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130784669378547755/snine_628fc2b5a_0e9faeb3-27e8-49b7-9021-419aa36e919d.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130784669378547755/snine_628fc2b5a_0e9faeb3-27e8-49b7-9021-419aa36e919d.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:54:34.283000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::0e9faeb3-27e8-49b7-9021-419aa36e919d",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::0e9faeb3-27e8-49b7-9021-419aa36e919d",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::0e9faeb3-27e8-49b7-9021-419aa36e919d",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::0e9faeb3-27e8-49b7-9021-419aa36e919d",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::0e9faeb3-27e8-49b7-9021-419aa36e919d::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::0e9faeb3-27e8-49b7-9021-419aa36e919d",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::0e9faeb3-27e8-49b7-9021-419aa36e919d",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::0e9faeb3-27e8-49b7-9021-419aa36e919d",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::0e9faeb3-27e8-49b7-9021-419aa36e919d",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130781256389492787",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130781256389492787",
          "type": 0,
          "content": "**[628fc2b5a] <https://s.mj.run/F8EPwOiVDww> <https://s.mj.run/F8EPwOiVDww> Sure, I will provide you with English translations in an AI style that closely resembles your own language. --v 5.1 --s 100 --ar 9:16 --c 0 --q 2** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130781255647109200",
                  "filename": "snine_628fc2b5a_4b562ae4-50dc-4109-8e4f-ecdbc902efbd.png",
                  "size": 7595981,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130781255647109200/snine_628fc2b5a_4b562ae4-50dc-4109-8e4f-ecdbc902efbd.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130781255647109200/snine_628fc2b5a_4b562ae4-50dc-4109-8e4f-ecdbc902efbd.png",
                  "width": 1632,
                  "height": 2912,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T08:41:00.423000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::4b562ae4-50dc-4109-8e4f-ecdbc902efbd::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 1,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130784285243220040",
      "type": 0,
      "content": "**[100fceb5b] <https://s.mj.run/NIAv2Jp8-Q8> <https://s.mj.run/NIAv2Jp8-Q8> I want to generate an anime with the same clothes and scenes as the original image. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130784285226446880",
              "filename": "snine_100fceb5b_52655b99-0600-4217-83ea-bbce9cc6bbfb.png",
              "size": 6853553,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130784285226446880/snine_100fceb5b_52655b99-0600-4217-83ea-bbce9cc6bbfb.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130784285226446880/snine_100fceb5b_52655b99-0600-4217-83ea-bbce9cc6bbfb.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:53:02.558000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::52655b99-0600-4217-83ea-bbce9cc6bbfb",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::52655b99-0600-4217-83ea-bbce9cc6bbfb",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::52655b99-0600-4217-83ea-bbce9cc6bbfb",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::52655b99-0600-4217-83ea-bbce9cc6bbfb",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::52655b99-0600-4217-83ea-bbce9cc6bbfb::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::52655b99-0600-4217-83ea-bbce9cc6bbfb",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::52655b99-0600-4217-83ea-bbce9cc6bbfb",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::52655b99-0600-4217-83ea-bbce9cc6bbfb",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::52655b99-0600-4217-83ea-bbce9cc6bbfb",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130784122848170114",
      "type": 19,
      "content": "**[5a3ae4656] <https://s.mj.run/_fejMLgJjuE> <https://s.mj.run/_fejMLgJjuE> Close-up of bedside table,Real scene,night --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - Image #4 <@1097407545750077461>",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130784122541981696",
              "filename": "snine_5a3ae4656_0abed2b3-ea29-4e14-abdb-a93b0be04764.png",
              "size": 1431394,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130784122541981696/snine_5a3ae4656_0abed2b3-ea29-4e14-abdb-a93b0be04764.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130784122541981696/snine_5a3ae4656_0abed2b3-ea29-4e14-abdb-a93b0be04764.png",
              "width": 1024,
              "height": 1024,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:52:23.840000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::high_variation::1::0abed2b3-ea29-4e14-abdb-a93b0be04764::SOLO",
                      "style": 2,
                      "label": "Vary (Strong)",
                      "emoji": {
                          "name": "🪄"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::low_variation::1::0abed2b3-ea29-4e14-abdb-a93b0be04764::SOLO",
                      "style": 2,
                      "label": "Vary (Subtle)",
                      "emoji": {
                          "name": "🪄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::50::1::0abed2b3-ea29-4e14-abdb-a93b0be04764::SOLO",
                      "style": 2,
                      "label": "Zoom Out 2x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::75::1::0abed2b3-ea29-4e14-abdb-a93b0be04764::SOLO",
                      "style": 2,
                      "label": "Zoom Out 1.5x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::CustomZoom::0abed2b3-ea29-4e14-abdb-a93b0be04764",
                      "style": 2,
                      "label": "Custom Zoom",
                      "emoji": {
                          "name": "🔍"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_left::1::0abed2b3-ea29-4e14-abdb-a93b0be04764::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬅️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_right::1::0abed2b3-ea29-4e14-abdb-a93b0be04764::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "➡️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_up::1::0abed2b3-ea29-4e14-abdb-a93b0be04764::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬆️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_down::1::0abed2b3-ea29-4e14-abdb-a93b0be04764::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬇️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::BOOKMARK::0abed2b3-ea29-4e14-abdb-a93b0be04764",
                      "style": 2,
                      "emoji": {
                          "name": "❤️"
                      }
                  },
                  {
                      "type": 2,
                      "style": 5,
                      "label": "Web",
                      "url": "https://www.midjourney.com/app/jobs/0abed2b3-ea29-4e14-abdb-a93b0be04764/"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130782952696074281",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130782952696074281",
          "type": 0,
          "content": "**[5a3ae4656] <https://s.mj.run/_fejMLgJjuE> <https://s.mj.run/_fejMLgJjuE> Close-up of bedside table,Real scene,night --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130782950313709668",
                  "filename": "snine_5a3ae4656_e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc.png",
                  "size": 6268730,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130782950313709668/snine_5a3ae4656_e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130782950313709668/snine_5a3ae4656_e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc.png",
                  "width": 2048,
                  "height": 2048,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T08:47:44.854000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                          "style": 1,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130783951749918860",
      "type": 19,
      "content": "**[944e9309c] <https://s.mj.run/lQ5vzlVA3EY> <https://s.mj.run/lQ5vzlVA3EY> indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - Image #2 <@1097407545750077461>",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130783951456325654",
              "filename": "snine_944e9309c_95f2115e-3c0f-4cbf-b208-74d01850402d.png",
              "size": 1070063,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130783951456325654/snine_944e9309c_95f2115e-3c0f-4cbf-b208-74d01850402d.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130783951456325654/snine_944e9309c_95f2115e-3c0f-4cbf-b208-74d01850402d.png",
              "width": 1024,
              "height": 1024,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:51:43.047000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::high_variation::1::95f2115e-3c0f-4cbf-b208-74d01850402d::SOLO",
                      "style": 2,
                      "label": "Vary (Strong)",
                      "emoji": {
                          "name": "🪄"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::low_variation::1::95f2115e-3c0f-4cbf-b208-74d01850402d::SOLO",
                      "style": 2,
                      "label": "Vary (Subtle)",
                      "emoji": {
                          "name": "🪄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::50::1::95f2115e-3c0f-4cbf-b208-74d01850402d::SOLO",
                      "style": 2,
                      "label": "Zoom Out 2x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::75::1::95f2115e-3c0f-4cbf-b208-74d01850402d::SOLO",
                      "style": 2,
                      "label": "Zoom Out 1.5x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::CustomZoom::95f2115e-3c0f-4cbf-b208-74d01850402d",
                      "style": 2,
                      "label": "Custom Zoom",
                      "emoji": {
                          "name": "🔍"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_left::1::95f2115e-3c0f-4cbf-b208-74d01850402d::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬅️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_right::1::95f2115e-3c0f-4cbf-b208-74d01850402d::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "➡️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_up::1::95f2115e-3c0f-4cbf-b208-74d01850402d::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬆️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_down::1::95f2115e-3c0f-4cbf-b208-74d01850402d::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬇️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::BOOKMARK::95f2115e-3c0f-4cbf-b208-74d01850402d",
                      "style": 2,
                      "emoji": {
                          "name": "❤️"
                      }
                  },
                  {
                      "type": 2,
                      "style": 5,
                      "label": "Web",
                      "url": "https://www.midjourney.com/app/jobs/95f2115e-3c0f-4cbf-b208-74d01850402d/"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130781230015721543",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130781230015721543",
          "type": 0,
          "content": "**[944e9309c] <https://s.mj.run/lQ5vzlVA3EY> <https://s.mj.run/lQ5vzlVA3EY> indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130781229407535194",
                  "filename": "snine_944e9309c_efb876c3-0024-49d2-a41f-cc6cf6ce5d3f.png",
                  "size": 5496105,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130781229407535194/snine_944e9309c_efb876c3-0024-49d2-a41f-cc6cf6ce5d3f.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130781229407535194/snine_944e9309c_efb876c3-0024-49d2-a41f-cc6cf6ce5d3f.png",
                  "width": 2048,
                  "height": 2048,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T08:40:54.135000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 1,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 1,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130783885328908308",
      "type": 0,
      "content": "**[ca762ced9] A bear sits in front of a computer, fully engrossed in its coding project. The room is dimly lit, with soft rays of sunlight filtering through the curtains. The bear's fur glistens in the warm glow, as it diligently types lines of code onto the keyboard. Its paws move swiftly and purposefully, navigating through complex algorithms and debugging errors with ease. The camera captures the scene from a slightly elevated angle, showcasing the bear's focused expression and intense concentration. The lens type accentuates the details of the bear's fur, highlighting its rich texture and shades of brown. The time of day is late afternoon, casting long shadows across the room and creating a cozy ambiance. The style of the photograph is reminiscent of a vintage black and white image, adding a touch of nostalgia to the modern setting. The bear's dedication to coding is amplified by this classic aesthetic, symbolizing the timeless pursuit of knowledge and innovation. If this scene were captured on film, it would be on a high-quality black and white film, enhancing the contrast and depth of the image. The film's grain adds a subtle artistic touch, further immersing the viewer into the bear's world of coding. In this unique and captivating image, the bear's passion for coding is beautifully portrayed, inspiring viewers to embrace their own pursuits with determination and focus. --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130783884775264338",
              "filename": "snine_ca762ced9_A_bear_sits_in_front_of_a_computer_fully_engro_f98bf3fb-dd23-49c2-8389-5fbc3aaa6088.png",
              "size": 6639793,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130783884775264338/snine_ca762ced9_A_bear_sits_in_front_of_a_computer_fully_engro_f98bf3fb-dd23-49c2-8389-5fbc3aaa6088.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130783884775264338/snine_ca762ced9_A_bear_sits_in_front_of_a_computer_fully_engro_f98bf3fb-dd23-49c2-8389-5fbc3aaa6088.png",
              "width": 2048,
              "height": 2048,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:51:27.211000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::f98bf3fb-dd23-49c2-8389-5fbc3aaa6088",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::f98bf3fb-dd23-49c2-8389-5fbc3aaa6088",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::f98bf3fb-dd23-49c2-8389-5fbc3aaa6088",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::f98bf3fb-dd23-49c2-8389-5fbc3aaa6088",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::f98bf3fb-dd23-49c2-8389-5fbc3aaa6088::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::f98bf3fb-dd23-49c2-8389-5fbc3aaa6088",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::f98bf3fb-dd23-49c2-8389-5fbc3aaa6088",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::f98bf3fb-dd23-49c2-8389-5fbc3aaa6088",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::f98bf3fb-dd23-49c2-8389-5fbc3aaa6088",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130783096145444864",
      "type": 0,
      "content": "**[628fc2b5a] <https://s.mj.run/F8EPwOiVDww> <https://s.mj.run/F8EPwOiVDww> Sure, I will provide you with English translations in an AI style that closely resembles your own language. --v 5.1 --s 100 --ar 9:16 --c 0 --q 2** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130783095512113212",
              "filename": "snine_628fc2b5a_381811d8-49e1-4aef-a24b-786ae5ec84d6.png",
              "size": 7626641,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130783095512113212/snine_628fc2b5a_381811d8-49e1-4aef-a24b-786ae5ec84d6.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130783095512113212/snine_628fc2b5a_381811d8-49e1-4aef-a24b-786ae5ec84d6.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:48:19.055000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::381811d8-49e1-4aef-a24b-786ae5ec84d6",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::381811d8-49e1-4aef-a24b-786ae5ec84d6",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::381811d8-49e1-4aef-a24b-786ae5ec84d6",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::381811d8-49e1-4aef-a24b-786ae5ec84d6",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::381811d8-49e1-4aef-a24b-786ae5ec84d6::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::381811d8-49e1-4aef-a24b-786ae5ec84d6",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::381811d8-49e1-4aef-a24b-786ae5ec84d6",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::381811d8-49e1-4aef-a24b-786ae5ec84d6",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::381811d8-49e1-4aef-a24b-786ae5ec84d6",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130782952696074281",
      "type": 0,
      "content": "**[5a3ae4656] <https://s.mj.run/_fejMLgJjuE> <https://s.mj.run/_fejMLgJjuE> Close-up of bedside table,Real scene,night --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130782950313709668",
              "filename": "snine_5a3ae4656_e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc.png",
              "size": 6268730,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130782950313709668/snine_5a3ae4656_e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130782950313709668/snine_5a3ae4656_e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc.png",
              "width": 2048,
              "height": 2048,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:47:44.854000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                      "style": 1,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::e0b29ab7-0254-4e72-b9d6-5642a1c9a7cc",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130782742670475264",
      "type": 0,
      "content": "**[66d37b0b6] <https://s.mj.run/zaTqgZ2DpeM> <https://s.mj.run/zaTqgZ2DpeM> Face transformed into an anime style. --v 5.2 --s 1 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130782741936484454",
              "filename": "snine_66d37b0b6_01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b.png",
              "size": 6827905,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130782741936484454/snine_66d37b0b6_01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130782741936484454/snine_66d37b0b6_01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:46:54.780000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::01c8dec1-1388-4f1f-b0a7-1ff7c8a1c81b",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130781893114200074",
      "type": 0,
      "content": "**[975bdaa93] indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130781892568944660",
              "filename": "snine_975bdaa93_indoorbedside_tablesoft_lightingfeaturesreal_3c24ecc1-67d2-44e3-a0d0-855235bed5ab.png",
              "size": 6234146,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130781892568944660/snine_975bdaa93_indoorbedside_tablesoft_lightingfeaturesreal_3c24ecc1-67d2-44e3-a0d0-855235bed5ab.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130781892568944660/snine_975bdaa93_indoorbedside_tablesoft_lightingfeaturesreal_3c24ecc1-67d2-44e3-a0d0-855235bed5ab.png",
              "width": 2048,
              "height": 2048,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:43:32.230000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::3c24ecc1-67d2-44e3-a0d0-855235bed5ab",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::3c24ecc1-67d2-44e3-a0d0-855235bed5ab",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::3c24ecc1-67d2-44e3-a0d0-855235bed5ab",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::3c24ecc1-67d2-44e3-a0d0-855235bed5ab",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::3c24ecc1-67d2-44e3-a0d0-855235bed5ab::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::3c24ecc1-67d2-44e3-a0d0-855235bed5ab",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::3c24ecc1-67d2-44e3-a0d0-855235bed5ab",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::3c24ecc1-67d2-44e3-a0d0-855235bed5ab",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::3c24ecc1-67d2-44e3-a0d0-855235bed5ab",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130781256389492787",
      "type": 0,
      "content": "**[628fc2b5a] <https://s.mj.run/F8EPwOiVDww> <https://s.mj.run/F8EPwOiVDww> Sure, I will provide you with English translations in an AI style that closely resembles your own language. --v 5.1 --s 100 --ar 9:16 --c 0 --q 2** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130781255647109200",
              "filename": "snine_628fc2b5a_4b562ae4-50dc-4109-8e4f-ecdbc902efbd.png",
              "size": 7595981,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130781255647109200/snine_628fc2b5a_4b562ae4-50dc-4109-8e4f-ecdbc902efbd.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130781255647109200/snine_628fc2b5a_4b562ae4-50dc-4109-8e4f-ecdbc902efbd.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:41:00.423000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::4b562ae4-50dc-4109-8e4f-ecdbc902efbd::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                      "style": 1,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::4b562ae4-50dc-4109-8e4f-ecdbc902efbd",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130781230015721543",
      "type": 0,
      "content": "**[944e9309c] <https://s.mj.run/lQ5vzlVA3EY> <https://s.mj.run/lQ5vzlVA3EY> indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 1:1 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130781229407535194",
              "filename": "snine_944e9309c_efb876c3-0024-49d2-a41f-cc6cf6ce5d3f.png",
              "size": 5496105,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130781229407535194/snine_944e9309c_efb876c3-0024-49d2-a41f-cc6cf6ce5d3f.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130781229407535194/snine_944e9309c_efb876c3-0024-49d2-a41f-cc6cf6ce5d3f.png",
              "width": 2048,
              "height": 2048,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:40:54.135000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                      "style": 1,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                      "style": 1,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::efb876c3-0024-49d2-a41f-cc6cf6ce5d3f",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130779429984026634",
      "type": 0,
      "content": "**[670d33bd6] <https://s.mj.run/7B9UqrUTUQw> <https://s.mj.run/7B9UqrUTUQw> I want it to be made into an anime, and it should be exactly like the original image. --v 5.1 --s 100 --ar 9:16 --c 0 --q 2** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130779429396811816",
              "filename": "snine_670d33bd6_374f9f58-27cf-413c-b0dc-168b94c52396.png",
              "size": 7378723,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130779429396811816/snine_670d33bd6_374f9f58-27cf-413c-b0dc-168b94c52396.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130779429396811816/snine_670d33bd6_374f9f58-27cf-413c-b0dc-168b94c52396.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:33:44.974000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::374f9f58-27cf-413c-b0dc-168b94c52396",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::374f9f58-27cf-413c-b0dc-168b94c52396",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::374f9f58-27cf-413c-b0dc-168b94c52396",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::374f9f58-27cf-413c-b0dc-168b94c52396",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::374f9f58-27cf-413c-b0dc-168b94c52396::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::374f9f58-27cf-413c-b0dc-168b94c52396",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::374f9f58-27cf-413c-b0dc-168b94c52396",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::374f9f58-27cf-413c-b0dc-168b94c52396",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::374f9f58-27cf-413c-b0dc-168b94c52396",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130777852103622717",
      "type": 0,
      "content": "**[a29146ca9] <https://s.mj.run/yiG-9qLrbFM> <https://s.mj.run/yiG-9qLrbFM> To compare AI styles that resemble images. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130777851365441566",
              "filename": "snine_a29146ca9_dd15e90e-978b-45c0-a9a0-7956e6c4633c.png",
              "size": 7666347,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130777851365441566/snine_a29146ca9_dd15e90e-978b-45c0-a9a0-7956e6c4633c.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130777851365441566/snine_a29146ca9_dd15e90e-978b-45c0-a9a0-7956e6c4633c.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:27:28.778000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::dd15e90e-978b-45c0-a9a0-7956e6c4633c",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::dd15e90e-978b-45c0-a9a0-7956e6c4633c",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::dd15e90e-978b-45c0-a9a0-7956e6c4633c",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::dd15e90e-978b-45c0-a9a0-7956e6c4633c",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::dd15e90e-978b-45c0-a9a0-7956e6c4633c::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::dd15e90e-978b-45c0-a9a0-7956e6c4633c",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::dd15e90e-978b-45c0-a9a0-7956e6c4633c",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::dd15e90e-978b-45c0-a9a0-7956e6c4633c",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::dd15e90e-978b-45c0-a9a0-7956e6c4633c",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130777015482601512",
      "type": 0,
      "content": "**[5ec691cb1] indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130777014870220881",
              "filename": "snine_5ec691cb1_indoorbedside_tablesoft_lightingfeaturesreal_d44e6121-c702-424c-86f9-04b75d9559c7.png",
              "size": 6264746,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130777014870220881/snine_5ec691cb1_indoorbedside_tablesoft_lightingfeaturesreal_d44e6121-c702-424c-86f9-04b75d9559c7.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130777014870220881/snine_5ec691cb1_indoorbedside_tablesoft_lightingfeaturesreal_d44e6121-c702-424c-86f9-04b75d9559c7.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:24:09.312000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::d44e6121-c702-424c-86f9-04b75d9559c7",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::d44e6121-c702-424c-86f9-04b75d9559c7",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::d44e6121-c702-424c-86f9-04b75d9559c7",
                      "style": 1,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::d44e6121-c702-424c-86f9-04b75d9559c7",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::d44e6121-c702-424c-86f9-04b75d9559c7::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::d44e6121-c702-424c-86f9-04b75d9559c7",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::d44e6121-c702-424c-86f9-04b75d9559c7",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::d44e6121-c702-424c-86f9-04b75d9559c7",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::d44e6121-c702-424c-86f9-04b75d9559c7",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130776997891670076",
      "type": 0,
      "content": "**[e3132126d] indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130776997153493092",
              "filename": "snine_e3132126d_indoorbedside_tablesoft_lightingfeaturesreal_a665f149-838a-4b2c-8060-615d1efcb179.png",
              "size": 6024392,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130776997153493092/snine_e3132126d_indoorbedside_tablesoft_lightingfeaturesreal_a665f149-838a-4b2c-8060-615d1efcb179.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130776997153493092/snine_e3132126d_indoorbedside_tablesoft_lightingfeaturesreal_a665f149-838a-4b2c-8060-615d1efcb179.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:24:05.118000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::a665f149-838a-4b2c-8060-615d1efcb179",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::a665f149-838a-4b2c-8060-615d1efcb179",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::a665f149-838a-4b2c-8060-615d1efcb179",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::a665f149-838a-4b2c-8060-615d1efcb179",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::a665f149-838a-4b2c-8060-615d1efcb179::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::a665f149-838a-4b2c-8060-615d1efcb179",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::a665f149-838a-4b2c-8060-615d1efcb179",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::a665f149-838a-4b2c-8060-615d1efcb179",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::a665f149-838a-4b2c-8060-615d1efcb179",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130776835513397309",
      "type": 0,
      "content": "**[8d37f4e57] <https://s.mj.run/Ox-UT6Huy7c> <https://s.mj.run/Ox-UT6Huy7c> Anime --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130776832640290836",
              "filename": "snine_8d37f4e57_5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad.png",
              "size": 6526803,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130776832640290836/snine_8d37f4e57_5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130776832640290836/snine_8d37f4e57_5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:23:26.404000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::5e8329f7-0b8f-49ad-9bc9-fc7db54d2cad",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130776282788016138",
      "type": 0,
      "content": "**[73fc08515] <https://s.mj.run/weskbxmsVyE> indoor,bedside table,soft lighting,features,real --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130776282028851311",
              "filename": "snine_73fc08515_40f4944e-15e6-48c0-8bc3-96d9b1afe4b8.png",
              "size": 6153610,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130776282028851311/snine_73fc08515_40f4944e-15e6-48c0-8bc3-96d9b1afe4b8.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130776282028851311/snine_73fc08515_40f4944e-15e6-48c0-8bc3-96d9b1afe4b8.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:21:14.624000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::40f4944e-15e6-48c0-8bc3-96d9b1afe4b8",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::40f4944e-15e6-48c0-8bc3-96d9b1afe4b8",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::40f4944e-15e6-48c0-8bc3-96d9b1afe4b8",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::40f4944e-15e6-48c0-8bc3-96d9b1afe4b8",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::40f4944e-15e6-48c0-8bc3-96d9b1afe4b8::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::40f4944e-15e6-48c0-8bc3-96d9b1afe4b8",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::40f4944e-15e6-48c0-8bc3-96d9b1afe4b8",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::40f4944e-15e6-48c0-8bc3-96d9b1afe4b8",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::40f4944e-15e6-48c0-8bc3-96d9b1afe4b8",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130774289554083872",
      "type": 0,
      "content": "**[cc65e67f4] 可爱的狗狗。fluffy, playful, loyal, friendly, adorable. Close-up. Wide-angle lens. Sunny afternoon. Vibrant colors. Digital photo. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130774289533128734",
              "filename": "snine_cc65e67f4_fluffy_playful_loyal_friendly_adorable._C_be2f1ab0-8818-452f-9b15-f7bac084c25c.png",
              "size": 6909832,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130774289533128734/snine_cc65e67f4_fluffy_playful_loyal_friendly_adorable._C_be2f1ab0-8818-452f-9b15-f7bac084c25c.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130774289533128734/snine_cc65e67f4_fluffy_playful_loyal_friendly_adorable._C_be2f1ab0-8818-452f-9b15-f7bac084c25c.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:13:19.400000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::be2f1ab0-8818-452f-9b15-f7bac084c25c",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::be2f1ab0-8818-452f-9b15-f7bac084c25c",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::be2f1ab0-8818-452f-9b15-f7bac084c25c",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::be2f1ab0-8818-452f-9b15-f7bac084c25c",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::be2f1ab0-8818-452f-9b15-f7bac084c25c::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::be2f1ab0-8818-452f-9b15-f7bac084c25c",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::be2f1ab0-8818-452f-9b15-f7bac084c25c",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::be2f1ab0-8818-452f-9b15-f7bac084c25c",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::be2f1ab0-8818-452f-9b15-f7bac084c25c",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130773918433693746",
      "type": 0,
      "content": "**[9ed869764] A fluffy golden retriever with a joyful expression and a shiny coat stands proudly in a lush green park. Its fur glistens under the warm rays of the afternoon sun, creating a beautiful contrast against the vibrant colors of the surrounding flowers and trees. The camera captures the dog's playful eyes, filled with curiosity and love. The lens used is a wide-angle lens, allowing for a wider perspective that encompasses the dog's surroundings. It is midday, and the sunlight casts a soft glow on the scene, adding a touch of warmth and serenity to the image. The style of the photograph is natural and candid, capturing the dog's genuine happiness and charm. The film used is a high-quality color film, enhancing the richness of the colors and textures in the image. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130773917800333342",
              "filename": "snine_9ed869764_A_fluffy_golden_retriever_with_a_joyful_expres_89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6.png",
              "size": 6818460,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130773917800333342/snine_9ed869764_A_fluffy_golden_retriever_with_a_joyful_expres_89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130773917800333342/snine_9ed869764_A_fluffy_golden_retriever_with_a_joyful_expres_89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:11:50.918000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::89a3ee48-87f6-40cd-8b8c-9d24fd21a7e6",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130773017224544347",
      "type": 19,
      "content": "**[6498b60fc] A black hole devouring Earth. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - Image #4 <@1097407545750077461>",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130773016935153754",
              "filename": "snine_6498b60fc_A_black_hole_devouring_Earth._1e06fdf3-4396-4fc6-a188-7af4552e18dd.png",
              "size": 1871242,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130773016935153754/snine_6498b60fc_A_black_hole_devouring_Earth._1e06fdf3-4396-4fc6-a188-7af4552e18dd.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130773016935153754/snine_6498b60fc_A_black_hole_devouring_Earth._1e06fdf3-4396-4fc6-a188-7af4552e18dd.png",
              "width": 816,
              "height": 1456,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:08:16.053000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::high_variation::1::1e06fdf3-4396-4fc6-a188-7af4552e18dd::SOLO",
                      "style": 2,
                      "label": "Vary (Strong)",
                      "emoji": {
                          "name": "🪄"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::low_variation::1::1e06fdf3-4396-4fc6-a188-7af4552e18dd::SOLO",
                      "style": 2,
                      "label": "Vary (Subtle)",
                      "emoji": {
                          "name": "🪄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::50::1::1e06fdf3-4396-4fc6-a188-7af4552e18dd::SOLO",
                      "style": 2,
                      "label": "Zoom Out 2x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::75::1::1e06fdf3-4396-4fc6-a188-7af4552e18dd::SOLO",
                      "style": 2,
                      "label": "Zoom Out 1.5x",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::CustomZoom::1e06fdf3-4396-4fc6-a188-7af4552e18dd",
                      "style": 2,
                      "label": "Custom Zoom",
                      "emoji": {
                          "name": "🔍"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::Outpaint::100::1::1e06fdf3-4396-4fc6-a188-7af4552e18dd::SOLO",
                      "style": 2,
                      "label": "Make Square",
                      "emoji": {
                          "name": "↔️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_left::1::1e06fdf3-4396-4fc6-a188-7af4552e18dd::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬅️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_right::1::1e06fdf3-4396-4fc6-a188-7af4552e18dd::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "➡️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_up::1::1e06fdf3-4396-4fc6-a188-7af4552e18dd::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬆️"
                      }
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::pan_down::1::1e06fdf3-4396-4fc6-a188-7af4552e18dd::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "⬇️"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::BOOKMARK::1e06fdf3-4396-4fc6-a188-7af4552e18dd",
                      "style": 2,
                      "emoji": {
                          "name": "❤️"
                      }
                  },
                  {
                      "type": 2,
                      "style": 5,
                      "label": "Web",
                      "url": "https://www.midjourney.com/app/jobs/1e06fdf3-4396-4fc6-a188-7af4552e18dd/"
                  }
              ]
          }
      ],
      "message_reference": {
          "channel_id": "1109782665743306813",
          "message_id": "1130771206036000819",
          "guild_id": "1097409128491651132"
      },
      "referenced_message": {
          "id": "1130771206036000819",
          "type": 0,
          "content": "**[6498b60fc] A black hole devouring Earth. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
          "channel_id": "1109782665743306813",
          "author": {
              "id": "936929561302675456",
              "username": "Midjourney Bot",
              "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
              "discriminator": "9282",
              "public_flags": 589824,
              "flags": 589824,
              "bot": true,
              "banner": null,
              "accent_color": null,
              "global_name": null,
              "avatar_decoration": null,
              "display_name": null,
              "banner_color": null
          },
          "attachments": [
              {
                  "id": "1130771205373313085",
                  "filename": "snine_6498b60fc_A_black_hole_devouring_Earth._80f1e044-1ffc-40c0-b018-e043c3acc86f.png",
                  "size": 8149740,
                  "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130771205373313085/snine_6498b60fc_A_black_hole_devouring_Earth._80f1e044-1ffc-40c0-b018-e043c3acc86f.png",
                  "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130771205373313085/snine_6498b60fc_A_black_hole_devouring_Earth._80f1e044-1ffc-40c0-b018-e043c3acc86f.png",
                  "width": 1632,
                  "height": 2912,
                  "content_type": "image/png"
              }
          ],
          "embeds": [],
          "mentions": [
              {
                  "id": "1097407545750077461",
                  "username": ".snine",
                  "avatar": null,
                  "discriminator": "0",
                  "public_flags": 0,
                  "flags": 0,
                  "banner": null,
                  "accent_color": null,
                  "global_name": "Snine",
                  "avatar_decoration": null,
                  "display_name": "Snine",
                  "banner_color": null
              }
          ],
          "mention_roles": [],
          "pinned": false,
          "mention_everyone": false,
          "tts": false,
          "timestamp": "2023-07-18T08:01:04.232000+00:00",
          "edited_timestamp": null,
          "flags": 0,
          "components": [
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::1::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                          "style": 2,
                          "label": "U1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::2::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                          "style": 2,
                          "label": "U2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::3::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                          "style": 2,
                          "label": "U3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::upsample::4::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                          "style": 1,
                          "label": "U4"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::reroll::0::80f1e044-1ffc-40c0-b018-e043c3acc86f::SOLO",
                          "style": 2,
                          "emoji": {
                              "name": "🔄"
                          }
                      }
                  ]
              },
              {
                  "type": 1,
                  "components": [
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::1::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                          "style": 2,
                          "label": "V1"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::2::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                          "style": 2,
                          "label": "V2"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::3::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                          "style": 2,
                          "label": "V3"
                      },
                      {
                          "type": 2,
                          "custom_id": "MJ::JOB::variation::4::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                          "style": 2,
                          "label": "V4"
                      }
                  ]
              }
          ]
      }
  },
  {
      "id": "1130771582718062603",
      "type": 0,
      "content": "**[c110f4786] A beautiful cat with silky fur, mesmerizing green eyes, and a graceful posture. Its fur is a combination of shades of gray, black, and white, creating a striking pattern that resembles delicate brush strokes on a canvas. The cat exudes elegance and confidence as it gracefully moves through its environment. With each step, its paws seem to glide effortlessly, leaving behind an air of mystery and grace. The camera captures this majestic creature from a close-up perspective, allowing us to see every intricate detail of its fur and the intensity in its eyes. The lens used is a macro lens, emphasizing the fine textures and patterns on the cat's coat. The photograph is taken during the early morning hours when the soft golden sunlight bathes the scene, casting a warm glow on the cat's fur. The style of the photograph is artistic, with a hint of surrealism, capturing the essence of the cat's beauty in a dreamlike manner. The film used is a high-quality color film, enhancing the vibrancy of the colors and adding depth to the image. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130771582382526564",
              "filename": "snine_c110f4786_A_beautiful_cat_with_silky_fur_mesmerizing_gre_e3e08383-183a-4868-a9ad-72d646223199.png",
              "size": 7611510,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130771582382526564/snine_c110f4786_A_beautiful_cat_with_silky_fur_mesmerizing_gre_e3e08383-183a-4868-a9ad-72d646223199.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130771582382526564/snine_c110f4786_A_beautiful_cat_with_silky_fur_mesmerizing_gre_e3e08383-183a-4868-a9ad-72d646223199.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:02:34.040000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::e3e08383-183a-4868-a9ad-72d646223199",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::e3e08383-183a-4868-a9ad-72d646223199",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::e3e08383-183a-4868-a9ad-72d646223199",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::e3e08383-183a-4868-a9ad-72d646223199",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::e3e08383-183a-4868-a9ad-72d646223199::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::e3e08383-183a-4868-a9ad-72d646223199",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::e3e08383-183a-4868-a9ad-72d646223199",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::e3e08383-183a-4868-a9ad-72d646223199",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::e3e08383-183a-4868-a9ad-72d646223199",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130771240865513583",
      "type": 0,
      "content": "**[291694988] A little dog is walking in the field. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130771240345403452",
              "filename": "snine_291694988_A_little_dog_is_walking_in_the_field._7c5a37f0-d4ec-43ff-b324-5507471fce24.png",
              "size": 7270542,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130771240345403452/snine_291694988_A_little_dog_is_walking_in_the_field._7c5a37f0-d4ec-43ff-b324-5507471fce24.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130771240345403452/snine_291694988_A_little_dog_is_walking_in_the_field._7c5a37f0-d4ec-43ff-b324-5507471fce24.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:01:12.536000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::7c5a37f0-d4ec-43ff-b324-5507471fce24",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::7c5a37f0-d4ec-43ff-b324-5507471fce24",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::7c5a37f0-d4ec-43ff-b324-5507471fce24",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::7c5a37f0-d4ec-43ff-b324-5507471fce24",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::7c5a37f0-d4ec-43ff-b324-5507471fce24::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::7c5a37f0-d4ec-43ff-b324-5507471fce24",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::7c5a37f0-d4ec-43ff-b324-5507471fce24",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::7c5a37f0-d4ec-43ff-b324-5507471fce24",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::7c5a37f0-d4ec-43ff-b324-5507471fce24",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130771206036000819",
      "type": 0,
      "content": "**[6498b60fc] A black hole devouring Earth. --v 5.2 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130771205373313085",
              "filename": "snine_6498b60fc_A_black_hole_devouring_Earth._80f1e044-1ffc-40c0-b018-e043c3acc86f.png",
              "size": 8149740,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130771205373313085/snine_6498b60fc_A_black_hole_devouring_Earth._80f1e044-1ffc-40c0-b018-e043c3acc86f.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130771205373313085/snine_6498b60fc_A_black_hole_devouring_Earth._80f1e044-1ffc-40c0-b018-e043c3acc86f.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T08:01:04.232000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                      "style": 1,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::80f1e044-1ffc-40c0-b018-e043c3acc86f::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::80f1e044-1ffc-40c0-b018-e043c3acc86f",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  },
  {
      "id": "1130768895146463273",
      "type": 0,
      "content": "**[866ee4db0] <https://s.mj.run/OdZBo85egdU> <https://s.mj.run/OdZBo85egdU> A mesmerizing galaxy with vibrant hues of purple and blue, swirling and dancing in a cosmic ballet. The camera hovers above the spiral arms, capturing the breathtaking beauty of this celestial masterpiece. The lens used is a wide-angle lens, allowing for a sweeping view of the entire galaxy. The time of day is set during the midnight hour, when the stars shine their brightest against the dark canvas of space. The style of the photograph is ethereal and dreamlike, with a touch of surrealism. The film used is a digital sensor, enabling crisp details and vivid colors to be captured with precision. --v 5.1 --s 100 --ar 9:16 --c 0 --q 1** - <@1097407545750077461> (fast)",
      "channel_id": "1109782665743306813",
      "author": {
          "id": "936929561302675456",
          "username": "Midjourney Bot",
          "avatar": "f6ce562a6b4979c4b1cbc5b436d3be76",
          "discriminator": "9282",
          "public_flags": 589824,
          "flags": 589824,
          "bot": true,
          "banner": null,
          "accent_color": null,
          "global_name": null,
          "avatar_decoration": null,
          "display_name": null,
          "banner_color": null
      },
      "attachments": [
          {
              "id": "1130768894404087868",
              "filename": "snine_866ee4db0_13c684d3-c5c1-41c5-86d0-0317d5a7b002.png",
              "size": 8150413,
              "url": "https://cdn.discordapp.com/attachments/1109782665743306813/1130768894404087868/snine_866ee4db0_13c684d3-c5c1-41c5-86d0-0317d5a7b002.png",
              "proxy_url": "https://media.discordapp.net/attachments/1109782665743306813/1130768894404087868/snine_866ee4db0_13c684d3-c5c1-41c5-86d0-0317d5a7b002.png",
              "width": 1632,
              "height": 2912,
              "content_type": "image/png"
          }
      ],
      "embeds": [],
      "mentions": [
          {
              "id": "1097407545750077461",
              "username": ".snine",
              "avatar": null,
              "discriminator": "0",
              "public_flags": 0,
              "flags": 0,
              "banner": null,
              "accent_color": null,
              "global_name": "Snine",
              "avatar_decoration": null,
              "display_name": "Snine",
              "banner_color": null
          }
      ],
      "mention_roles": [],
      "pinned": false,
      "mention_everyone": false,
      "tts": false,
      "timestamp": "2023-07-18T07:51:53.273000+00:00",
      "edited_timestamp": null,
      "flags": 0,
      "components": [
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::1::13c684d3-c5c1-41c5-86d0-0317d5a7b002",
                      "style": 2,
                      "label": "U1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::2::13c684d3-c5c1-41c5-86d0-0317d5a7b002",
                      "style": 2,
                      "label": "U2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::3::13c684d3-c5c1-41c5-86d0-0317d5a7b002",
                      "style": 2,
                      "label": "U3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::upsample::4::13c684d3-c5c1-41c5-86d0-0317d5a7b002",
                      "style": 2,
                      "label": "U4"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::reroll::0::13c684d3-c5c1-41c5-86d0-0317d5a7b002::SOLO",
                      "style": 2,
                      "emoji": {
                          "name": "🔄"
                      }
                  }
              ]
          },
          {
              "type": 1,
              "components": [
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::1::13c684d3-c5c1-41c5-86d0-0317d5a7b002",
                      "style": 2,
                      "label": "V1"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::2::13c684d3-c5c1-41c5-86d0-0317d5a7b002",
                      "style": 2,
                      "label": "V2"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::3::13c684d3-c5c1-41c5-86d0-0317d5a7b002",
                      "style": 2,
                      "label": "V3"
                  },
                  {
                      "type": 2,
                      "custom_id": "MJ::JOB::variation::4::13c684d3-c5c1-41c5-86d0-0317d5a7b002",
                      "style": 2,
                      "label": "V4"
                  }
              ]
          }
      ]
  }
]
export enum VerificationUseStatusEnum {
  UNUSED,
  USED,
}

export const ModelsMapCn = {
  1: '系统内置大模型',
  2: '百度千帆大模型',
  3: '清华智谱大模型'
}
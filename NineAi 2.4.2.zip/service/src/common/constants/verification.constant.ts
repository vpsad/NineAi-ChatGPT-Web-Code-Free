/**
 * Registration: 注册账户
 * PasswordReset: 重置密码
 * ChangeEmail: 换绑邮箱
 */
export enum VerificationEnum {
  Registration,
  PasswordReset,
  ChangeEmail,
}
